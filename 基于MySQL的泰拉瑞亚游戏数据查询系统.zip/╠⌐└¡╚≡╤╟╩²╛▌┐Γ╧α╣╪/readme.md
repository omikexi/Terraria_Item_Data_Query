# 🎮 泰拉瑞亚游戏数据查询系统（MySQL版）

<div align="center">
  <img src="https://picsum.photos/id/237/800/200" alt="Terraria Database" width="600">
  <p>基于MySQL的泰拉瑞亚游戏数据管理与查询解决方案</p>
</div>

## 📋 项目简介

本系统为泰拉瑞亚玩家提供了一套完整的游戏数据管理工具，通过MySQL数据库存储游戏内核心数据（物品、Buff、怪物、指令等），并支持通过SQL查询快速检索信息。系统包含数据库设计、查询存储过程及Excel数据导入功能，适用于各类泰拉瑞亚相关工具开发或玩家数据查询需求。

## 🛠️ 系统组成

```mermaid
graph TD
    A[数据库结构] --> A1[8张核心数据表]
    A --> A2[8个查询存储过程]
    B[数据导入工具] --> B1[Excel数据解析]
    B --> B2[MySQL批量导入]
    C[查询功能] --> C1[直接SQL查询]
    C --> C2[存储过程调用]
```

## 🔧 数据库搭建步骤

### 1. 创建数据库

```sql
CREATE DATABASE IF NOT EXISTS terraria
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;
```

### 2. 切换数据库

```sql
USE terraria;
```

### 3. 创建数据表结构

| 表名 | 用途 | 核心字段 |
|------|------|----------|
| `armor_id` | 存储盔甲数据 | `id, head, body, leg` |
| `buff_id` | 存储Buff效果数据 | `id, name, inner_name, type` |
| `command` | 存储游戏指令数据 | `id, command, notes` |
| `event` | 存储游戏事件数据 | `id, name, inner_name` |
| `monster_id` | 存储怪物数据 | `id, name, inner_name, description` |
| `mount_id` | 存储坐骑数据 | `id, name, inner_name` |
| `object_id` | 存储物品数据 | `id, name, inner_name` |
| `prefix_id` | 存储前缀数据 | `id, name` |

```sql
-- 盔甲数据表
CREATE TABLE armor_id (
  id double,
  head varchar(255),
  body varchar(255),
  leg varchar(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Buff数据表
CREATE TABLE buff_id (
  id double,
  name varchar(255),
  inner_name varchar(255),
  type char(2)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 指令数据表
CREATE TABLE command (
  id double,
  command varchar(255),
  notes varchar(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 事件数据表
CREATE TABLE event (
  id double,
  name varchar(255),
  inner_name varchar(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 怪物数据表
CREATE TABLE monster_id (
  id double,
  name varchar(255),
  inner_name varchar(255),
  description varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 坐骑数据表
CREATE TABLE mount_id (
  id double,
  name varchar(255),
  inner_name varchar(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 物品数据表
CREATE TABLE object_id (
  id double,
  name varchar(255),
  inner_name varchar(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 前缀数据表
CREATE TABLE prefix_id (
  id double,
  name varchar(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### 4. 创建查询存储过程

存储过程提供了便捷的模糊查询功能，支持按关键词快速检索各类数据：

```sql
DELIMITER //

-- 查询Buff（按名称）
CREATE PROCEDURE SearchBuff(IN keyword VARCHAR(255))
BEGIN
    SELECT * FROM buff_id WHERE name LIKE CONCAT('%', keyword, '%');
END //

-- 查询事件（按名称）
CREATE PROCEDURE SearchEvent(IN keyword VARCHAR(255))
BEGIN
    SELECT * FROM event WHERE name LIKE CONCAT('%', keyword, '%');
END //

-- 查询怪物（按名称）
CREATE PROCEDURE SearchMonster(IN keyword VARCHAR(255))
BEGIN
    SELECT * FROM monster_id WHERE name LIKE CONCAT('%', keyword, '%');
END //

-- 查询坐骑（按名称）
CREATE PROCEDURE SearchMount(IN keyword VARCHAR(255))
BEGIN
    SELECT * FROM mount_id WHERE name LIKE CONCAT('%', keyword, '%');
END //

-- 查询物品（按名称）
CREATE PROCEDURE SearchObject(IN keyword VARCHAR(255))
BEGIN
    SELECT * FROM object_id WHERE name LIKE CONCAT('%', keyword, '%');
END //

-- 查询前缀（按名称）
CREATE PROCEDURE SearchPrefix(IN keyword VARCHAR(255))
BEGIN
    SELECT * FROM prefix_id WHERE name LIKE CONCAT('%', keyword, '%');
END //

-- 查询指令（按备注）
CREATE PROCEDURE SearchCommand(IN keyword VARCHAR(255))
BEGIN
    SELECT * FROM command WHERE notes LIKE CONCAT('%', keyword, '%');
END //

-- 查询盔甲（按头部/身体/腿部）
CREATE PROCEDURE SearchArmor(IN keyword VARCHAR(255))
BEGIN
    SELECT * FROM armor_id 
    WHERE head LIKE CONCAT('%', keyword, '%')
    OR body LIKE CONCAT('%', keyword, '%')
    OR leg LIKE CONCAT('%', keyword, '%');
END //

DELIMITER ;
```

## 📊 数据导入工具使用说明

### 工具功能

通过Python脚本将Excel格式的游戏数据批量导入到MySQL数据库，支持灵活配置导入参数，适用于初始化数据库或更新数据。

### 文件结构

```
项目根目录/
├── main.py          # 数据导入主程序
└── config.py        # 配置文件（数据库连接、Excel路径等）
```

### 配置说明（config.py）

```python
# 数据库配置 - 根据实际环境修改
DB_CONFIG = {
    'host': 'localhost',    # 数据库主机地址
    'user': 'root',         # 数据库用户名
    'password': '',         # 数据库密码
    'database': 'terraria', # 数据库名称
    'port': '3306'          # 数据库端口
}

# Excel文件配置 - 设置Excel文件路径
EXCEL_CONFIG = {
    'file_path': r'',       # Excel文件路径（示例：r'C:\data\terraria_armor.xlsx'）
    'engine': 'openpyxl'    # Excel引擎（处理.xlsx格式，无需修改）
}

# 导入配置 - 设置导入参数
IMPORT_CONFIG = {
    'table_name': 'armor_id', # 目标数据表名（需与数据库中表名一致）
    'if_exists': 'append'     # 数据存在时的处理方式：
                              # append(追加)、replace(替换)、fail(报错)
}
```

### 使用步骤

1. **准备数据**：确保Excel文件格式与目标数据表结构匹配（列名一致）
   
2. **安装依赖**：
   ```bash
   pip install pandas sqlalchemy pymysql openpyxl
   ```

3. **配置参数**：编辑`config.py`，填写数据库连接信息和Excel文件路径

4. **运行脚本**：
   ```bash
   python main.py
   ```

5. **查看结果**：脚本会输出导入成功或失败信息，失败时会显示具体错误原因

## 🔍 数据查询方法

### 直接SQL查询示例

```sql
-- 查询所有Buff
SELECT * FROM buff_id WHERE name LIKE '%%';

-- 查询所有事件
SELECT * FROM event WHERE name LIKE '%%';

-- 查询所有怪物
SELECT * FROM monster_id WHERE name LIKE '%%';

-- 查询所有坐骑
SELECT * FROM mount_id WHERE name LIKE '%%';

-- 查询所有物品
SELECT * FROM object_id WHERE name LIKE '%%';

-- 查询所有前缀
SELECT * FROM prefix_id WHERE name LIKE '%%';

-- 查询所有指令
SELECT * FROM command WHERE notes LIKE '%%';

-- 查询包含"铁"的盔甲
SELECT * FROM armor_id WHERE CONCAT_WS(',', head, body, leg) LIKE CONCAT('%', '铁', '%');
```

### 存储过程调用示例

```sql
-- 查询包含"生命"的Buff
CALL SearchBuff('生命');

-- 查询包含"雨"的事件
CALL SearchEvent('雨');

-- 查询包含"史莱姆"的怪物
CALL SearchMonster('史莱姆');

-- 查询包含"猪龙鱼"的坐骑
CALL SearchMount('猪龙鱼');

-- 查询包含"剑"的物品
CALL SearchObject('剑');

-- 查询包含"伤害"的指令
CALL SearchCommand('伤害');

-- 查询包含"铜"的盔甲
CALL SearchArmor('铜');
```


## ⚠️ 注意事项

- 首次使用需先执行「数据库搭建步骤」创建表结构
- Excel导入时，确保表头与数据库表字段完全一致（大小写不敏感）
- `if_exists='replace'`会清空目标表原有数据，建议操作前备份数据
- 数据库使用`utf8mb4`字符集，支持中文、特殊符号查询
- 不同泰拉瑞亚版本的物品ID可能存在差异，建议按游戏版本整理数据

## 🔄 数据更新

当游戏版本更新时，可按以下流程更新数据库：

1. 导出新版本游戏数据到Excel文件
2. 备份现有数据库（可选但推荐）
3. 修改`config.py`中的`DB_CONFIG`和`table_name`以及`file_path`
4. 根据需求设置`if_exists`参数（首次导入用`replace`，后续更新用`append`）
5. 运行`main.py`导入新数据
6. 通过查询验证数据完整性

---

<div align="center">
  <p>🎉 祝各位泰拉瑞亚玩家探险愉快！</p>
  <p>如有问题或建议，欢迎提交反馈</p>
</div>