import pandas as pd
from sqlalchemy import create_engine
from config import DB_CONFIG, EXCEL_CONFIG, IMPORT_CONFIG


def excel_to_mysql():
    try:
        df = pd.read_excel(
            EXCEL_CONFIG['file_path'],
            engine=EXCEL_CONFIG['engine']
        )

        engine = create_engine(
            f"mysql+pymysql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@"
            f"{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}"
        )

        df.to_sql(
            name=IMPORT_CONFIG['table_name'],
            con=engine,
            if_exists=IMPORT_CONFIG['if_exists'],
            index=False
        )

        print(f"数据已成功导入到表 {IMPORT_CONFIG['table_name']}！")

    except Exception as e:
        print(f"导入失败：{str(e)}")
    finally:
        if 'engine' in locals():
            engine.dispose()


if __name__ == "__main__":
    excel_to_mysql()
