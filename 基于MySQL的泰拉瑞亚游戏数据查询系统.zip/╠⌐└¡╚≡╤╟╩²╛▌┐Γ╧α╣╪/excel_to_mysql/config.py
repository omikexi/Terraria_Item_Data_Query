# 数据库配置
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'terraria',
    'port': '3306'
}

# Excel文件配置（Excel文件路径）
EXCEL_CONFIG = {
    'file_path': r'',
    'engine': 'openpyxl'
}

# 导入配置（要导入数据表的表名）
IMPORT_CONFIG = {
    'table_name': 'armor_id',
    'if_exists': 'append'
}
